# aSU kernel integration — research only

Target information supplied for initial analysis:
- MediaTek platform: MT6768
- Kernel reported by device: 5.10.246
- ABI: arm64-v8a
- Android: 16 / API 36
- Existing provider: KernelSU 4.2.0-rc3, UAPI 4

These facts do NOT establish that the vendor kernel source, matching config,
toolchain, symbol exports, or boot image are available.

No kernel patch is included in this starter. A standalone root framework requires
kernel-side privilege enforcement; an APK or userspace daemon alone cannot safely
create that capability. Preserve the existing working root setup while researching.
