package id.dapakz.asu

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext

private val Navy = Color(0xFF07111F)
private val Panel = Color(0xFF101F33)
private val Blue = Color(0xFF3B82F6)
private val Muted = Color(0xFF9AAFC9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AsuApp() }
    }
}

@Composable
private fun AsuApp() {
    val context = LocalContext.current
    var rootStatus by remember { mutableStateOf("Belum diperiksa") }
    var detail by remember { mutableStateOf("Tekan pemeriksaan untuk mendeteksi akses root yang tersedia.") }
    var checking by remember { mutableStateOf(false) }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Blue, background = Navy, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Navy) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(shape = RoundedCornerShape(14.dp), color = Color(0xFF123B70)) {
                            Icon(Icons.Default.Shield, null, Modifier.padding(12.dp), tint = Color(0xFF8FC0FF))
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("aSU", fontSize = 30.sp, fontWeight = FontWeight.Black, color = Color.White)
                            Text("ANDROID SUPERUSER", fontSize = 11.sp, color = Muted, letterSpacing = 2.sp)
                        }
                        Text("v0.1.0", color = Blue, fontSize = 12.sp)
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(22.dp)) {
                        Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text("SYSTEM OVERVIEW", color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp)
                            Text(rootStatus, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                            Text(detail, color = Muted, fontSize = 13.sp)
                            Button(
                                onClick = {
                                    checking = true
                                    rootStatus = "Memeriksa…"
                                    detail = "Memeriksa identitas proses melalui su."
                                    Thread {
                                        val result = try {
                                            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
                                            val output = p.inputStream.bufferedReader().readText().trim()
                                            val code = p.waitFor()
                                            if (code == 0 && output.contains("uid=0")) "Root tersedia: $output"
                                            else "Root tidak terkonfirmasi (exit $code)."
                                        } catch (e: Exception) {
                                            "Root tidak tersedia atau permintaan ditolak: ${e.javaClass.simpleName}"
                                        }
                                        context.mainExecutor.execute {
                                            detail = result
                                            rootStatus = if (result.startsWith("Root tersedia")) "Root terdeteksi" else "Belum terdeteksi"
                                            checking = false
                                        }
                                    }.start()
                                },
                                enabled = !checking,
                                modifier = Modifier.fillMaxWidth(),
                                colors = ButtonDefaults.buttonColors(containerColor = Blue)
                            ) {
                                if (checking) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                                else Icon(Icons.Default.Security, null)
                                Spacer(Modifier.width(8.dp))
                                Text(if (checking) "Memeriksa" else "Periksa akses root")
                            }
                        }
                    }
                }
                item { SectionTitle("CORE COMPONENTS") }
                item { FeatureCard(Icons.Default.AdminPanelSettings, "Superuser", "Tahap berikutnya: daftar aplikasi dan kebijakan izin.") }
                item { FeatureCard(Icons.Default.Extension, "Modules", "Tahap berikutnya: inventaris modul dan status pemasangan.") }
                item { FeatureCard(Icons.Default.Terminal, "Logs", "Tahap berikutnya: log daemon dan diagnostik sistem.") }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFF102B4E)), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp)) {
                            Text("DEVELOPMENT BUILD", color = Color(0xFF9CCBFF), fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "Prototipe Manager read-only. Belum memasang root, mengubah kernel, mengelola modul, atau menyediakan root engine aSU mandiri.",
                                color = Color(0xFFD4E6FF), fontSize = 12.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(text, color = Muted, fontSize = 11.sp, letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold)
}

@Composable
private fun FeatureCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(16.dp)) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Muted, fontSize = 12.sp)
            }
        }
    }
}
