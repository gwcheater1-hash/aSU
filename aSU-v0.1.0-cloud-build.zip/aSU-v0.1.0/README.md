# aSU — Android Superuser
Version: 0.1.0 development scaffold

## Build without a PC
This project includes a GitHub Actions workflow at `.github/workflows/android.yml`.
Upload the extracted project to a GitHub repository from your phone. Open the repository's
Actions tab, select **Build aSU APK**, choose **Run workflow**, and download the
`aSU-debug-apk` artifact after the workflow succeeds.

## Local build
The Android Gradle Plugin is 8.7.3 and this project uses Gradle 8.9. Do not use
Gradle 9.9.2 for this project. Local builds also require Android SDK Platform 36.

## Included
- Kotlin + Jetpack Compose blue/dark dashboard
- Read-only `su -c id` root detection
- GitHub Actions cloud build workflow
- Native/kernel architecture notes

## Not included
- Independent aSU root engine
- Kernel patches or boot image modifications
- Privileged daemon or init service
- Module installation/removal
- Superuser policy enforcement

The current APK detects an existing root provider (such as KernelSU); it does not
replace it. Do not describe this build as an independent root framework.

## Device notes
Initial diagnostics supplied: model V2332, device/vendor device V2333, MT6768,
kernel 5.10.246, arm64-v8a, Android 16, KernelSU 4.2.0-rc3.
Confirm exact product/board identity and obtain matching vendor kernel sources
before attempting kernel work.
