# aSU native layer (planned)

This directory reserves the native userspace layer. The v0.1.0 APK is intentionally
read-only and does not start a privileged daemon.

A future daemon must not trust arbitrary app-supplied commands. Before implementation,
define and review:
- authenticated IPC (peer credentials + explicit protocol version)
- narrowly scoped operations rather than an arbitrary root shell endpoint
- per-UID authorization and auditable consent
- SELinux domain and init integration
- lifecycle, crash recovery, and rollback behavior

Do not install a daemon as a root service until those controls and the kernel-side
authorization mechanism have been implemented and security-reviewed.
